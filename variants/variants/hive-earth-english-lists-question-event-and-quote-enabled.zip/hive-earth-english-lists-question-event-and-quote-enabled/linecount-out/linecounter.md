***

EXTENSION NAME - linecounter  
EXTENSION VERSION - 0.2.7  

***

count time - 2022-06-24 14:47:04  
count workspace - c:\Users\Karim\Downloads\Article APSEC\hive\variants\hive-earth-english-lists-question-event-and-quote-enabled  
total files - 553  
total code lines - 20753  
total comment lines - 1672  
total blank lines - 3157  



***

STATISTICS

|extension | total code | total comment | total blank | percent|
|----|----|----|----|----|
|.json | 2095 | 8 | 80 | 10|
|.js | 120 | 8 | 14 | 0.58|
|.xml | 100 | 0 | 0 | 0.48|
| | 55 | 3 | 9 | 0.27|
|.ts | 8747 | 1184 | 1690 | 42|
|.html | 1847 | 60 | 208 | 8.9|
|.config | 11 | 0 | 1 | 0.053|
|.cs | 4859 | 270 | 852 | 23|
|.md | 223 | 3 | 120 | 1.1|
|.lg | 67 | 0 | 16 | 0.32|
|.svg | 433 | 20 | 0 | 2.1|
|.csproj | 42 | 0 | 1 | 0.20|
|.yml | 17 | 0 | 0 | 0.082|
|.scss | 1944 | 116 | 146 | 9.4|
|.cshtml | 158 | 0 | 20 | 0.76|
|.sln | 25 | 0 | 0 | 0.12|
|.user | 9 | 0 | 0 | 0.043|
|.md5 | 1 | 0 | 0 | 0.0048|
|||||

***



|filename | code | comment | blank|
|----|----|----|----|
|build\build.json | 619 | 0 | 23|
|smartapp\backend\Repositories\CardRepository.cs | 564 | 70 | 113|
|smartapp\frontend\src\assets\i18n\En.json | 438 | 0 | 22|
|smartapp\frontend\src\assets\i18n\Fr.json | 436 | 0 | 11|
|smartapp\backend\Api\v1\PostsController.cs | 339 | 14 | 40|
|smartapp\frontend\src\app\modules\posts\modules\question\edit-question-modal\edit-question-modal.component.ts | 327 | 57 | 50|
|smartapp\frontend\src\app\modules\posts\components\post-details-modal\post-details-modal.component.ts | 312 | 47 | 51|
|smartapp\frontend\src\assets\sass\components\cards\cards.scss | 291 | 21 | 28|
|smartapp\frontend\src\app\modules\highlights\top-posts-card-modal\top-posts-card-modal.component.scss | 269 | 11 | 10|
|smartapp\frontend\src\app\modules\flow\flow.component.ts | 268 | 101 | 41|
|smartapp\frontend\src\app\modules\posts\modules\event\edit-event-modal\edit-event-modal.component.ts | 262 | 53 | 41|
|smartapp\backend\DbInitializer.cs | 257 | 8 | 39|
|smartapp\backend\Api\v1\GroupController.cs | 252 | 16 | 42|
|smartapp\frontend\src\app\modules\account\components\edit-profile\edit-profile.component.ts | 245 | 10 | 27|
|smartapp\frontend\src\app\modules\posts\components\posts-main\posts-main.component.ts | 240 | 30 | 40|
|smartapp\frontend\src\app\modules\posts\posts.component.ts | 231 | 37 | 37|
|smartapp\frontend\src\app\modules\highlights\top-posts-card-modal\top-posts-card-modal.component.ts | 227 | 46 | 37|
|smartapp\backend\Api\v1\UserController.cs | 218 | 13 | 32|
|smartapp\frontend\src\assets\sass\components\Toolbar.scss | 199 | 21 | 9|
|smartapp\frontend\src\app\modules\account\modules\manage-groups\manage-groups.component.ts | 197 | 53 | 23|
|smartapp\frontend\angular.json | 179 | 0 | 1|
|smartapp\frontend\src\app\modules\posts\modules\quote\edit-quote-modal\edit-quote-modal.component.ts | 175 | 39 | 32|
|smartapp\frontend\src\app\services\api\user-controller.service.ts | 169 | 4 | 27|
|smartapp\frontend\src\assets\sass\layout\header.scss | 163 | 3 | 4|
|smartapp\backend\Api\v1\HighlightsController.cs | 162 | 10 | 20|
|smartapp\frontend\src\app\modules\authentication\register\register.component.ts | 152 | 28 | 16|
|smartapp\backend\Services\CardService.cs | 149 | 0 | 46|
|smartapp\backend\Repositories\GroupRepository.cs | 147 | 9 | 25|
|smartapp\frontend\src\app\modules\account\modules\manage-groups\group-details\group-details.component.ts | 146 | 35 | 23|
|smartapp\backend\Api\v1\FlowController.cs | 144 | 11 | 18|
|smartapp\frontend\src\app\modules\highlights\best-post\best-post.component.ts | 144 | 21 | 29|
|smartapp\frontend\src\assets\sass\components\View.scss | 140 | 26 | 17|
|smartapp\frontend\src\app\shared\components\reporting-card\reporting-card.component.ts | 138 | 19 | 25|
|smartapp\backend\Models\AccountViewModels.cs | 137 | 0 | 41|
|smartapp\frontend\tslint.json | 135 | 0 | 14|
|smartapp\frontend\src\app\modules\account\modules\manage-groups\edit-members-modal\edit-members-modal.component.ts | 129 | 27 | 20|
|smartapp\backend\Api\v1\AuthController.cs | 126 | 6 | 33|
|smartapp\backend\Startup.cs | 126 | 11 | 22|
|smartapp\frontend\src\app\modules\posts\modules\question\create-question\create-question.component.ts | 126 | 16 | 25|
|smartapp\frontend\src\app\modules\posts\modules\event\create-question\create-question.component.ts | 126 | 16 | 24|
|smartapp\frontend\src\app\services\api\group-controller.service.ts | 123 | 60 | 13|
|smartapp\frontend\src\app\modules\account\components\change-password\change-password.component.ts | 116 | 0 | 12|
|smartapp\frontend\src\app\modules\authentication\login\login.component.ts | 110 | 26 | 20|
|smartapp\backend\Api\v1\AnswerController.cs | 108 | 9 | 17|
|smartapp\frontend\src\app\modules\highlights\top-posts-card-modal\top-posts-card-modal.component.html | 106 | 4 | 13|
|smartapp\frontend\config.xml | 100 | 0 | 0|
|smartapp\frontend\src\app\modules\posts\modules\question\question.component.ts | 99 | 0 | 16|
|smartapp\frontend\src\app\services\helpers\images-processing.service.ts | 96 | 42 | 26|
|smartapp\frontend\package.json | 95 | 0 | 1|
|smartapp\backend\Repositories\AnswerRepository.cs | 92 | 1 | 17|
|smartapp\frontend\src\assets\sass\components\posts\top-posts.scss | 90 | 2 | 2|
|smartapp\frontend\src\app\modules\posts\components\top-posts\top-posts.component.ts | 90 | 13 | 19|
|smartapp\frontend\src\app\modules\posts\modules\event\event.component.ts | 90 | 0 | 13|
|smartapp\frontend\src\app\shared\components\event-card\event-card.component.ts | 88 | 12 | 18|
|smartapp\frontend\src\app\modules\account\components\edit-profile\edit-profile.component.html | 88 | 5 | 11|
|smartapp\backend\Models\ApplicationDbContext.cs | 87 | 5 | 18|
|smartapp\frontend\src\app\shared\components\question-card\question-card.component.ts | 87 | 18 | 16|
|smartapp\frontend\src\app\modules\posts\modules\quote\quote.component.ts | 87 | 0 | 13|
|smartapp\frontend\src\app\services\api\posts-controller.service.ts | 87 | 18 | 12|
|smartapp\frontend\src\assets\sass\main.scss | 86 | 3 | 13|
|smartapp\frontend\src\app\modules\posts\modules\question\create-settings\create-settings.component.ts | 86 | 14 | 21|
|smartapp\frontend\src\app\modules\posts\modules\event\create-settings\create-settings.component.ts | 86 | 14 | 21|
|smartapp\backend\Services\GroupService.cs | 85 | 0 | 12|
|smartapp\frontend\src\app\modules\posts\components\post-details-modal\post-details-modal.component.html | 84 | 1 | 8|
|smartapp\backend\Repositories\UserProfileRepository.cs | 83 | 21 | 16|
|smartapp\frontend\src\app\modules\posts\modules\question\create-answers\create-answers.component.ts | 82 | 3 | 18|
|smartapp\frontend\src\app\modules\account\modules\manage-groups\manage-groups.component.html | 81 | 4 | 5|
|smartapp\backend\Models\ManageViewModels.cs | 79 | 0 | 13|
|smartapp\frontend\src\assets\sass\views\login.scss | 75 | 0 | 1|
|smartapp\backend\Program.cs | 74 | 1 | 20|
|smartapp\backend\Startup.Auth.cs | 73 | 16 | 21|
|smartapp\frontend\src\app\modules\posts\components\choose-new-post-category\choose-new-post-category.component.scss | 73 | 0 | 0|
|smartapp\frontend\src\assets\sass\layout\post.scss | 72 | 0 | 0|
|smartapp\backend\Auth\JwtFactory.cs | 72 | 2 | 16|
|smartapp\frontend\src\app\modules\account\modules\settings\languages\languages.component.ts | 72 | 2 | 16|
|smartapp\frontend\src\app\shared\components\quote-card\quote-card.component.ts | 71 | 6 | 14|
|smartapp\frontend\src\app\modules\authentication\register\register.component.html | 71 | 0 | 14|
|smartapp\frontend\src\app\modules\posts\modules\question\preview\preview.component.ts | 70 | 7 | 12|
|smartapp\frontend\src\app\modules\posts\modules\event\preview\preview.component.ts | 70 | 7 | 10|
|smartapp\frontend\src\app\modules\account\modules\manage-groups\group-details\group-details.component.html | 69 | 3 | 2|
|smartapp\frontend\src\assets\sass\components\cards\templates\report.scss | 68 | 0 | 0|
|smartapp\backend\Repositories\Repository.cs | 67 | 0 | 9|
|smartapp\frontend\src\app\modules\posts\modules\quote\create-settings\create-settings.component.ts | 67 | 7 | 19|
|smartapp\frontend\src\app\modules\posts\modules\question\edit-question-modal\edit-question-modal.component.html | 67 | 2 | 5|
|smartapp\backend\Api\v1\PictureController.cs | 66 | 8 | 8|
|smartapp\frontend\src\app\modules\highlights\top-posts\top-posts.component.ts | 66 | 7 | 12|
|smartapp\frontend\src\app\services\group-management.service.ts | 66 | 25 | 13|
|smartapp\frontend\src\app\services\api\flow-controller.service.ts | 66 | 22 | 8|
|smartapp\frontend\src\app\modules\account\components\edit-profile\edit-profile.component.scss | 66 | 1 | 8|
|smartapp\backend\Views\Shared\_Layout.cshtml | 65 | 0 | 5|
|smartapp\frontend\src\app\modules\account\modules\manage-groups\edit-group-modal\edit-group-modal.component.html | 65 | 6 | 12|
|smartapp\frontend\src\app\modules\posts\components\posts-main\posts-main.component.html | 64 | 1 | 8|
|smartapp\frontend\src\app\shared\components\mood-card\mood-card.component.ts | 63 | 13 | 11|
|smartapp\frontend\src\app\modules\account\modules\manage-groups\create-group-modal\create-group-modal.component.html | 63 | 3 | 12|
|smartapp\frontend\google-services.json | 62 | 0 | 0|
|smartapp\backend\Services\UserProfileService.cs | 59 | 0 | 15|
|smartapp\frontend\src\app\app.module.ts | 59 | 0 | 6|
|smartapp\frontend\src\app\modules\posts\modules\event\edit-event-modal\edit-event-modal.component.html | 58 | 0 | 5|
|smartapp\frontend\src\app\shared\components\reporting-card\reporting-card.component.html | 56 | 1 | 11|
|smartapp\frontend\src\app\modules\highlights\best-post\best-post.component.html | 56 | 0 | 9|
|smartapp\frontend\test-config\mocks\groupControllerMock.ts | 55 | 0 | 10|
|smartapp\backend\Services\AnswerService.cs | 55 | 0 | 12|
|smartapp\frontend\src\app\modules\posts\modules\quote\preview\preview.component.ts | 54 | 7 | 10|
|smartapp\backend\Views\Shared\_LayoutMin.cshtml | 53 | 0 | 5|
|smartapp\frontend\src\app\services\api\data.service.ts | 53 | 38 | 7|
|smartapp\frontend\src\app\modules\account\modules\manage-groups\edit-group-modal\edit-group-modal.component.ts | 53 | 12 | 8|
|smartapp\frontend\src\app\modules\account\modules\manage-groups\create-group-modal\create-group-modal.component.ts | 53 | 11 | 9|
|smartapp\frontend\src\app\modules\posts\components\choose-new-post-category\choose-new-post-category.component.html | 52 | 0 | 3|
|smartapp\frontend\test-config\mocks\platformMock.ts | 50 | 1 | 13|
|smartapp\backend\Services\PictureService.cs | 50 | 0 | 7|
|smartapp\frontend\src\app\services\api\answer-controller.service.ts | 50 | 15 | 9|
|smartapp\frontend\src\app\modules\account\components\change-password\change-password.component.html | 50 | 3 | 4|
|smartapp\frontend\src\app\modules\posts\modules\question\question.component.html | 49 | 2 | 3|
|smartapp\frontend\src\app\modules\account\account.component.html | 49 | 0 | 2|
|smartapp\frontend\src\app\modules\posts\posts-routing.module.ts | 48 | 0 | 5|
|smartapp\frontend\src\app\modules\account\modules\manage-groups\edit-members-modal\edit-members-modal.component.html | 48 | 4 | 4|
|smartapp\frontend\src\app\modules\account\account.component.ts | 47 | 0 | 10|
|smartapp\frontend\test-config\mocks\userControllerMock.ts | 46 | 0 | 9|
|smartapp\backend\Security\Roles.cs | 46 | 0 | 10|
|smartapp\backend\Services\ICardService.cs | 45 | 0 | 9|
|resources\files\help-line\Primary_color.md | 44 | 0 | 15|
|smartapp\frontend\src\app\modules\posts\modules\event\event.component.html | 44 | 2 | 3|
|smartapp\frontend\src\app\modules\tabs\tabs-routing.module.ts | 44 | 0 | 3|
|smartapp\frontend\src\app\modules\posts\modules\quote\quote.component.html | 43 | 2 | 3|
|smartapp\frontend\src\app\modules\flow\flow.component.html | 43 | 10 | 9|
|smartapp\backend\Hive.csproj | 42 | 0 | 1|
|smartapp\frontend\src\assets\sass\components\posts\new-post.scss | 42 | 0 | 6|
|smartapp\frontend\src\app\modules\highlights\general-mood\general-mood.component.ts | 41 | 6 | 9|
|smartapp\frontend\test-config\webpack.test.js | 40 | 0 | 5|
|smartapp\frontend\src\app\app.component.ts | 40 | 10 | 7|
|smartapp\backend\Repositories\Interfaces\ICardRepository.cs | 39 | 1 | 4|
|smartapp\frontend\src\app\modules\posts\modules\quote\create-question\create-question.component.ts | 38 | 0 | 11|
|smartapp\frontend\src\app\modules\account\account-routing.module.ts | 38 | 0 | 2|
|smartapp\frontend\karma.conf.js | 37 | 8 | 1|
|smartapp\backend\Controllers\HomeController.cs | 37 | 0 | 6|
|smartapp\frontend\src\app\shared\components\event-card\event-card.component.html | 37 | 1 | 5|
|smartapp\frontend\src\app\modules\posts\modules\quote\edit-quote-modal\edit-quote-modal.component.html | 37 | 0 | 3|
|smartapp\frontend\src\app\services\api\highlights-controller.service.ts | 36 | 21 | 8|
|smartapp\frontend\src\app\modules\posts\components\choose-new-post-category\choose-new-post-category.component.ts | 35 | 6 | 8|
|smartapp\frontend\src\app\modules\flow\flow.component.scss | 35 | 4 | 3|
|smartapp\frontend\src\app\shared\components\question-card\question-card.component.html | 34 | 1 | 5|
|smartapp\frontend\src\app\modules\posts\modules\question\question.module.ts | 34 | 0 | 2|
|smartapp\backend\Properties\launchSettings.json | 32 | 0 | 0|
|smartapp\frontend\src\app\shared\components\quote-card\quote-card.component.html | 32 | 1 | 5|
|smartapp\frontend\src\app\modules\posts\posts.module.ts | 32 | 0 | 1|
|smartapp\frontend\src\app\modules\posts\modules\quote\quote.module.ts | 32 | 0 | 2|
|smartapp\frontend\src\app\modules\posts\modules\event\event.module.ts | 32 | 0 | 2|
|smartapp\frontend\src\app\modules\highlights\best-contributor\best-contributor.component.scss | 32 | 0 | 1|
|smartapp\frontend\src\app\services\helpers\network-provider.service.ts | 32 | 1 | 6|
|smartapp\frontend\test-config\mocks\ideaControllerMock.ts | 31 | 0 | 6|
|smartapp\frontend\src\app\shared\components\mood-card\mood-card.component.html | 31 | 1 | 5|
|smartapp\frontend\src\app\modules\authentication\login\login.component.html | 30 | 0 | 2|
|smartapp\frontend\src\app\shared\shared.module.ts | 29 | 0 | 10|
|smartapp\frontend\src\app\modules\account\modules\manage-groups\manage-groups.module.ts | 29 | 0 | 3|
|smartapp\frontend\src\app\modules\account\account.module.ts | 29 | 0 | 3|
|smartapp\frontend\test-config\karma.conf.js | 28 | 0 | 2|
|smartapp\frontend\src\app\modules\highlights\best-contributor\best-contributor.component.html | 28 | 0 | 1|
|smartapp\frontend\src\app\services\api\picture-controller.service.ts | 28 | 16 | 5|
|smartapp\backend\ViewModels\CardVM.cs | 27 | 0 | 3|
|smartapp\frontend\src\app\modules\highlights\best-contributor\best-contributor.component.ts | 27 | 3 | 8|
|smartapp\backend\DesignTimeDbContextFactory.cs | 26 | 0 | 2|
|smartapp\frontend\test-config\mocks\postsControllerMock.ts | 26 | 0 | 5|
|smartapp\frontend\src\assets\imgs\icons\header\close-blue.svg | 26 | 1 | 0|
|smartapp\frontend\src\app\modules\highlights\highlights.module.ts | 26 | 0 | 3|
|smartapp\frontend\src\app\services\auth-interceptor.service.ts | 26 | 0 | 7|
|resources\files\help-line\Post_creation.md | 25 | 0 | 10|
|smartapp\frontend\test-config\mocks\navMock.ts | 25 | 0 | 4|
|smartapp\backend\Services\IGroupService.cs | 25 | 0 | 1|
|smartapp\backend\Hive.sln | 25 | 0 | 0|
|smartapp\backend\Repositories\Interfaces\IGroupRepository.cs | 25 | 0 | 1|
|smartapp\backend\Models\Card.cs | 25 | 3 | 2|
|smartapp\backend\Models\UserProfile.cs | 25 | 3 | 2|
|smartapp\frontend\src\app\modules\authentication\authentication.module.ts | 25 | 0 | 1|
|smartapp\frontend\src\app\modules\authentication\authentication-routing.module.ts | 25 | 0 | 2|
|smartapp\frontend\src\app\services\api\auth-negate-guard.service.ts | 25 | 0 | 3|
|smartapp\frontend\test-config\mocks\highlightsControllerMock.ts | 24 | 0 | 5|
|smartapp\frontend\src\assets\sass\helpers\mixins.scss | 24 | 0 | 7|
|smartapp\backend\ViewModels\PostDetailsVM.cs | 24 | 0 | 2|
|smartapp\backend\Helpers\Constants.cs | 24 | 0 | 3|
|smartapp\backend\Repositories\PictureRepository.cs | 24 | 0 | 4|
|smartapp\frontend\src\app\modules\posts\modules\question\question-routing.module.ts | 24 | 0 | 3|
|smartapp\frontend\src\app\modules\posts\modules\question\create-question\create-question.component.html | 24 | 0 | 2|
|smartapp\frontend\src\app\modules\posts\modules\event\preview\preview.component.html | 24 | 0 | 3|
|smartapp\frontend\src\app\modules\posts\modules\event\create-question\create-question.component.html | 24 | 0 | 2|
|smartapp\frontend\src\app\modules\account\modules\settings\settings.component.html | 24 | 2 | 1|
|smartapp\frontend\src\app\services\api\auth-guard.service.ts | 24 | 0 | 3|
|smartapp\backend\Helpers\Tokens.cs | 23 | 1 | 2|
|smartapp\frontend\src\global.scss | 23 | 13 | 4|
|smartapp\frontend\src\app\app-routing.module.ts | 23 | 0 | 2|
|smartapp\backend\Models\JoinTables\CardGroup.cs | 23 | 0 | 7|
|smartapp\frontend\src\app\modules\posts\modules\event\event-routing.module.ts | 23 | 0 | 3|
|smartapp\frontend\src\app\modules\highlights\general-mood\general-mood.component.scss | 23 | 0 | 3|
|smartapp\frontend\src\app\modules\account\modules\settings\settings-routing.module.ts | 23 | 0 | 2|
|smartapp\frontend\tsconfig.json | 22 | 1 | 0|
|smartapp\frontend\src\index.html | 22 | 1 | 8|
|smartapp\backend\ViewModels\UpdatePasswordVM.cs | 22 | 0 | 7|
|smartapp\frontend\src\assets\sass\components\buttons.scss | 22 | 0 | 0|
|smartapp\frontend\src\assets\imgs\icons\mood\sad.svg | 22 | 1 | 0|
|smartapp\frontend\src\app\services\http-server-error-interceptor.service.ts | 22 | 1 | 3|
|smartapp\frontend\src\app\modules\posts\components\posts-main\posts-main.component.scss | 22 | 0 | 1|
|smartapp\frontend\src\app\modules\flow\flow.module.ts | 22 | 0 | 1|
|smartapp\backend\Helpers\Errors.cs | 21 | 0 | 3|
|smartapp\frontend\test-config\mocks\answerControllerMock.ts | 21 | 0 | 4|
|smartapp\backend\Services\IUserProfileService.cs | 21 | 0 | 2|
|smartapp\backend\Models\Group.cs | 21 | 2 | 2|
|smartapp\frontend\src\assets\imgs\icons\mood\happy.svg | 21 | 1 | 0|
|smartapp\frontend\src\assets\imgs\icons\close-black.svg | 21 | 1 | 0|
|smartapp\frontend\src\app\modules\posts\modules\question\preview\preview.component.html | 21 | 0 | 4|
|smartapp\frontend\src\app\modules\account\modules\manage-groups\manage-groups-routing.module.ts | 21 | 0 | 2|
|resources\files\help-line\Secondary_color-help.md | 21 | 0 | 8|
|smartapp\backend\Repositories\Interfaces\IUserProfileRepository.cs | 20 | 0 | 2|
|smartapp\frontend\src\assets\imgs\icons\header\posts.svg | 20 | 1 | 0|
|smartapp\frontend\src\assets\imgs\icons\header\replay.svg | 20 | 1 | 0|
|smartapp\frontend\src\assets\imgs\icons\posts\more-vertical.svg | 20 | 1 | 0|
|smartapp\frontend\src\assets\imgs\icons\mood\indifferent.svg | 20 | 1 | 0|
|smartapp\frontend\src\assets\imgs\icons\mood\sunglasses.svg | 20 | 1 | 0|
|smartapp\frontend\src\assets\imgs\icons\mood\muted.svg | 20 | 1 | 0|
|smartapp\frontend\src\app\modules\posts\modules\quote\quote-routing.module.ts | 20 | 0 | 3|
|smartapp\frontend\src\app\modules\tabs\tabs.component.html | 20 | 0 | 3|
|smartapp\frontend\src\app\modules\highlights\highlights.component.ts | 20 | 4 | 5|
|smartapp\frontend\src\app\modules\highlights\top-posts\top-posts.component.html | 20 | 0 | 0|
|smartapp\backend\ViewModels\FullUserVM.cs | 19 | 0 | 5|
|smartapp\backend\ViewModels\TopPostVM.cs | 19 | 0 | 2|
|smartapp\backend\Auth\JwtIssuerOptions.cs | 19 | 27 | 11|
|smartapp\frontend\src\assets\imgs\icons\nav\posts.svg | 19 | 1 | 0|
|smartapp\frontend\src\app\shared\components\quote-card\quote-card.component.spec.ts | 19 | 0 | 6|
|smartapp\frontend\src\app\shared\components\reporting-card\reporting-card.component.spec.ts | 19 | 0 | 5|
|smartapp\frontend\src\app\shared\components\event-card\event-card.component.spec.ts | 19 | 0 | 6|
|smartapp\frontend\src\app\shared\components\mood-card\mood-card.component.spec.ts | 19 | 0 | 5|
|smartapp\frontend\src\app\shared\components\question-card\question-card.component.spec.ts | 19 | 0 | 6|
|smartapp\frontend\src\app\modules\posts\posts.component.spec.ts | 19 | 0 | 5|
|smartapp\frontend\src\app\modules\posts\modules\quote\preview\preview.component.html | 19 | 0 | 1|
|smartapp\frontend\src\app\modules\posts\modules\quote\quote.component.spec.ts | 19 | 0 | 6|
|smartapp\frontend\src\app\modules\posts\modules\quote\preview\preview.component.spec.ts | 19 | 0 | 6|
|smartapp\frontend\src\app\modules\posts\components\top-posts\top-posts.component.spec.ts | 19 | 0 | 5|
|smartapp\frontend\src\app\modules\posts\modules\question\edit-question-modal\edit-question-modal.component.scss | 19 | 4 | 2|
|smartapp\frontend\src\app\modules\posts\modules\quote\edit-quote-modal\edit-quote-modal.component.spec.ts | 19 | 0 | 6|
|smartapp\frontend\src\app\modules\posts\modules\quote\create-settings\create-settings.component.spec.ts | 19 | 0 | 6|
|smartapp\frontend\src\app\modules\posts\modules\question\question.component.spec.ts | 19 | 0 | 6|
|smartapp\frontend\src\app\modules\posts\modules\question\preview\preview.component.spec.ts | 19 | 0 | 6|
|smartapp\frontend\src\app\modules\posts\modules\question\edit-question-modal\edit-question-modal.component.spec.ts | 19 | 0 | 6|
|smartapp\frontend\src\app\modules\posts\modules\question\create-settings\create-settings.component.spec.ts | 19 | 0 | 6|
|smartapp\frontend\src\app\modules\posts\components\posts-main\posts-main.component.spec.ts | 19 | 0 | 5|
|smartapp\frontend\src\app\modules\posts\modules\question\create-question\create-question.component.spec.ts | 19 | 0 | 6|
|smartapp\frontend\src\app\modules\posts\modules\quote\create-question\create-question.component.spec.ts | 19 | 0 | 6|
|smartapp\frontend\src\app\modules\posts\modules\question\create-answers\create-answers.component.spec.ts | 19 | 0 | 6|
|smartapp\frontend\src\app\modules\posts\modules\event\edit-event-modal\edit-event-modal.component.scss | 19 | 4 | 2|
|smartapp\frontend\src\app\modules\posts\modules\event\event.component.spec.ts | 19 | 0 | 6|
|smartapp\frontend\src\app\modules\posts\components\post-details-modal\post-details-modal.component.spec.ts | 19 | 0 | 5|
|smartapp\frontend\src\app\modules\posts\modules\event\preview\preview.component.spec.ts | 19 | 0 | 6|
|smartapp\frontend\src\app\modules\posts\modules\event\create-settings\create-settings.component.spec.ts | 19 | 0 | 6|
|smartapp\frontend\src\app\modules\tabs\tabs.component.spec.ts | 19 | 0 | 5|
|smartapp\frontend\src\app\modules\posts\modules\event\edit-event-modal\edit-event-modal.component.spec.ts | 19 | 0 | 6|
|smartapp\frontend\src\app\modules\highlights\highlights.component.spec.ts | 19 | 0 | 5|
|smartapp\frontend\src\app\modules\posts\components\choose-new-post-category\choose-new-post-category.component.spec.ts | 19 | 0 | 5|
|smartapp\frontend\src\app\modules\highlights\top-posts-card-modal\top-posts-card-modal.component.spec.ts | 19 | 0 | 5|
|smartapp\frontend\src\app\modules\posts\modules\event\create-question\create-question.component.spec.ts | 19 | 0 | 6|
|smartapp\frontend\src\app\modules\highlights\general-mood\general-mood.component.spec.ts | 19 | 0 | 5|
|smartapp\frontend\src\app\modules\highlights\best-post\best-post.component.spec.ts | 19 | 0 | 5|
|smartapp\frontend\src\app\modules\highlights\top-posts\top-posts.component.spec.ts | 19 | 0 | 5|
|smartapp\frontend\src\app\modules\flow\flow.component.spec.ts | 19 | 0 | 5|
|smartapp\frontend\src\app\modules\highlights\best-contributor\best-contributor.component.spec.ts | 19 | 0 | 5|
|smartapp\frontend\src\app\modules\authentication\login\login.component.spec.ts | 19 | 0 | 5|
|smartapp\frontend\src\app\modules\authentication\register\register.component.spec.ts | 19 | 0 | 5|
|smartapp\frontend\src\app\modules\account\modules\settings\languages\languages.component.spec.ts | 19 | 0 | 5|
|smartapp\frontend\src\app\modules\account\modules\settings\settings.component.spec.ts | 19 | 0 | 5|
|smartapp\frontend\src\app\modules\account\modules\manage-groups\manage-groups.component.spec.ts | 19 | 0 | 5|
|smartapp\frontend\src\app\modules\account\modules\manage-groups\edit-members-modal\edit-members-modal.component.spec.ts | 19 | 0 | 5|
|smartapp\frontend\src\app\modules\account\modules\manage-groups\group-details\group-details.component.spec.ts | 19 | 0 | 5|
|smartapp\frontend\src\app\modules\account\modules\manage-groups\edit-group-modal\edit-group-modal.component.spec.ts | 19 | 0 | 5|
|smartapp\frontend\src\app\modules\account\modules\manage-groups\create-group-modal\create-group-modal.component.spec.ts | 19 | 0 | 5|
|smartapp\frontend\src\app\modules\account\components\edit-profile\edit-profile.component.spec.ts | 19 | 0 | 5|
|smartapp\frontend\src\app\modules\account\components\change-password\change-password.component.spec.ts | 19 | 0 | 5|
|smartapp\frontend\src\app\modules\account\account.component.spec.ts | 19 | 0 | 5|
|smartapp\frontend\src\test.ts | 18 | 4 | 3|
|smartapp\backend\bundleconfig.json | 18 | 5 | 2|
|smartapp\backend\ViewModels\BestContributorVM.cs | 18 | 0 | 3|
|smartapp\backend\ViewModels\EditableCardVM.cs | 18 | 0 | 1|
|smartapp\backend\ViewModels\ReportVM.cs | 18 | 0 | 2|
|smartapp\backend\Services\IAnswerService.cs | 18 | 0 | 1|
|smartapp\frontend\src\assets\imgs\icons\nav\highlights.svg | 18 | 1 | 0|
|smartapp\frontend\src\app\shared\interfaces\posts\cardVM.ts | 18 | 0 | 16|
|smartapp\frontend\src\app\modules\posts\components\top-posts\top-posts.component.html | 18 | 0 | 2|
|smartapp\frontend\src\app\modules\account\modules\settings\settings.module.ts | 18 | 0 | 1|
|resources\files\help-line\Cards_image.md | 17 | 0 | 12|
|smartapp\backend\docker-compose.yml | 17 | 0 | 0|
|smartapp\backend\ViewModels\CreatePostVM.cs | 17 | 0 | 1|
|smartapp\backend\ViewModels\GroupVM.cs | 17 | 0 | 3|
|smartapp\backend\Repositories\Interfaces\IRepository.cs | 17 | 0 | 1|
|smartapp\frontend\src\app\modules\highlights\highlights.component.html | 17 | 0 | 0|
|smartapp\backend\Dockerfile | 16 | 0 | 3|
|smartapp\backend\ViewModels\PostVM.cs | 16 | 0 | 3|
|smartapp\backend\ViewModels\UpdatePostVM.cs | 16 | 0 | 1|
|smartapp\backend\ViewModels\TargetGroupVM.cs | 16 | 0 | 4|
|smartapp\backend\Services\IPictureService.cs | 16 | 0 | 1|
|smartapp\backend\Models\Answer.cs | 16 | 0 | 2|
|smartapp\backend\appsettings.json | 16 | 0 | 1|
|smartapp\frontend\src\assets\imgs\icons\quote.svg | 16 | 1 | 0|
|smartapp\frontend\src\app\modules\posts\modules\question\create-settings\create-settings.component.html | 16 | 0 | 1|
|smartapp\frontend\src\app\modules\posts\modules\event\create-settings\create-settings.component.html | 16 | 0 | 1|
|smartapp\frontend\src\app\modules\tabs\tabs.module.ts | 16 | 0 | 3|
|smartapp\frontend\src\app\modules\highlights\highlights-routing.module.ts | 16 | 0 | 2|
|smartapp\frontend\src\app\modules\flow\flow-routing.module.ts | 16 | 0 | 2|
|smartapp\frontend\src\app\app.component.spec.ts | 16 | 1 | 6|
|resources\files\help-line\Title_question-help.md | 16 | 1 | 18|
|smartapp\frontend\test-config\karma-test-shim.js | 15 | 0 | 6|
|smartapp\frontend\test-config\mocks\flowControllerMock.ts | 15 | 0 | 3|
|smartapp\frontend\test-config\mocks\dataServiceMock.ts | 15 | 0 | 4|
|smartapp\backend\ViewModels\UserVM.cs | 15 | 0 | 3|
|smartapp\backend\Repositories\Interfaces\IAnswerRepository.cs | 15 | 0 | 1|
|smartapp\backend\Models\Result.cs | 15 | 0 | 2|
|smartapp\backend\Models\JoinTables\UserCardViews.cs | 15 | 0 | 4|
|smartapp\backend\Models\JoinTables\UserCardLikes.cs | 15 | 0 | 3|
|smartapp\backend\Models\JoinTables\GroupUser.cs | 15 | 0 | 4|
|smartapp\frontend\src\assets\imgs\icons\nav\flow.svg | 15 | 1 | 0|
|smartapp\frontend\src\assets\imgs\icons\nav\account.svg | 15 | 1 | 0|
|smartapp\frontend\src\app\shared\interfaces\posts\cardModel.ts | 15 | 0 | 10|
|smartapp\frontend\src\app\shared\interfaces\posts\postDetails.ts | 15 | 0 | 12|
|smartapp\frontend\.browserslistrc | 14 | 2 | 3|
|smartapp\frontend\tsconfig.spec.json | 14 | 1 | 3|
|smartapp\frontend\src\assets\sass\base\typography.scss | 14 | 0 | 1|
|smartapp\frontend\test-config\mocks\pictureControllerMock.ts | 14 | 0 | 3|
|smartapp\backend\ViewModels\CreateGroupVM.cs | 14 | 0 | 2|
|smartapp\frontend\src\theme\variables.scss | 14 | 0 | 6|
|smartapp\frontend\src\assets\imgs\email.svg | 14 | 1 | 0|
|smartapp\backend\Repositories\Interfaces\IPictureRepository.cs | 14 | 0 | 1|
|smartapp\backend\Auth\AuthSettings.cs | 14 | 0 | 0|
|smartapp\backend\Models\Reporting.cs | 14 | 0 | 2|
|smartapp\frontend\.editorconfig | 13 | 1 | 3|
|smartapp\frontend\test-config\mocks\translateServiceMock.ts | 13 | 0 | 4|
|smartapp\backend\Views\Home\Index.cshtml | 13 | 0 | 4|
|smartapp\frontend\src\assets\imgs\icons\clapping.svg | 13 | 0 | 0|
|smartapp\frontend\src\app\services\server-config.service.ts | 13 | 0 | 3|
|smartapp\frontend\src\app\modules\posts\modules\event\create-question\create-question.component.scss | 13 | 3 | 1|
|smartapp\frontend\src\app\modules\account\modules\settings\settings.component.ts | 13 | 0 | 4|
|smartapp\frontend\tsconfig.app.json | 12 | 1 | 2|
|smartapp\backend\ViewModels\EditGroupVM.cs | 12 | 0 | 3|
|smartapp\backend\Views\Shared\Error.cshtml | 12 | 0 | 4|
|smartapp\backend\ViewModels\GeneralMoodVM.cs | 12 | 0 | 1|
|smartapp\backend\ViewModels\UpdateMembersVM.cs | 12 | 0 | 2|
|smartapp\backend\ViewModels\UpdateProfilePictureVM.cs | 12 | 0 | 1|
|smartapp\backend\Models\Identifier.cs | 12 | 0 | 2|
|smartapp\frontend\src\assets\imgs\icons\header\menu-black.svg | 12 | 1 | 0|
|smartapp\frontend\src\assets\imgs\icons\right-arrow.svg | 12 | 1 | 0|
|smartapp\frontend\src\assets\imgs\icons\left-arrow.svg | 12 | 1 | 0|
|smartapp\frontend\src\assets\imgs\icons\left-arrow-black.svg | 12 | 1 | 0|
|smartapp\frontend\src\app\services\server-config.service.spec.ts | 12 | 0 | 4|
|smartapp\frontend\src\app\modules\tabs\tabs.component.scss | 12 | 0 | 3|
|smartapp\frontend\src\app\services\http-server-error-interceptor.service.spec.ts | 12 | 0 | 4|
|smartapp\frontend\src\app\services\helpers\network-provider.service.spec.ts | 12 | 0 | 4|
|smartapp\frontend\src\app\services\helpers\images-processing.service.spec.ts | 12 | 0 | 4|
|smartapp\frontend\src\app\services\auth-interceptor.service.spec.ts | 12 | 0 | 4|
|smartapp\frontend\src\app\services\api\auth-guard.service.spec.ts | 12 | 0 | 4|
|smartapp\frontend\src\app\services\group-management.service.spec.ts | 12 | 0 | 4|
|smartapp\frontend\src\app\services\api\answer-controller.service.spec.ts | 12 | 0 | 4|
|smartapp\frontend\src\app\services\api\picture-controller.service.spec.ts | 12 | 0 | 4|
|smartapp\frontend\src\app\services\api\highlights-controller.service.spec.ts | 12 | 0 | 4|
|smartapp\frontend\src\app\services\api\user-controller.service.spec.ts | 12 | 0 | 4|
|smartapp\frontend\src\app\services\api\posts-controller.service.spec.ts | 12 | 0 | 4|
|smartapp\frontend\src\app\services\api\group-controller.service.spec.ts | 12 | 0 | 4|
|smartapp\frontend\src\app\services\api\flow-controller.service.spec.ts | 12 | 0 | 4|
|smartapp\frontend\src\app\services\api\data.service.spec.ts | 12 | 0 | 4|
|smartapp\frontend\src\app\services\api\auth-negate-guard.service.spec.ts | 12 | 0 | 4|
|resources\files\help-line\Like_button.md | 12 | 0 | 6|
|smartapp\backend\app.config | 11 | 0 | 1|
|resources\files\help-line\Splash-help.md | 11 | 0 | 10|
|smartapp\backend\Views\_ViewStart.cshtml | 11 | 0 | 1|
|smartapp\backend\ViewModels\SignInVM.cs | 11 | 0 | 2|
|smartapp\backend\Helpers\AppSettings.cs | 11 | 0 | 1|
|smartapp\backend\ViewModels\UserViewCardVM.cs | 11 | 0 | 3|
|smartapp\backend\Models\AdminViewModel.cs | 11 | 0 | 1|
|smartapp\backend\Models\ApplicationUser.cs | 11 | 2 | 1|
|resources\files\help-line\Event_cards.md | 11 | 0 | 5|
|smartapp\backend\Auth\IJwtFactory.cs | 11 | 0 | 1|
|smartapp\backend\Models\Helpers\CardTypes.cs | 11 | 0 | 4|
|smartapp\frontend\src\app\shared\interfaces\user\user-update.ts | 11 | 0 | 7|
|smartapp\frontend\src\app\shared\interfaces\posts\create-post.ts | 11 | 0 | 1|
|smartapp\frontend\src\app\shared\interfaces\user\full-user.ts | 11 | 0 | 8|
|smartapp\frontend\src\app\shared\interfaces\highlights\top-post.ts | 11 | 0 | 8|
|smartapp\frontend\src\app\modules\posts\modules\question\create-answers\create-answers.component.html | 11 | 0 | 2|
|resources\files\help-line\Quote-help.md | 10 | 0 | 5|
|resources\files\help-line\Suggestion-help.md | 10 | 0 | 7|
|resources\files\help-line\Icon_application.md | 10 | 0 | 5|
|smartapp\backend\ViewModels\PictureVM.cs | 10 | 0 | 2|
|smartapp\backend\bower.json | 10 | 0 | 0|
|smartapp\backend\Models\Choice.cs | 10 | 0 | 2|
|smartapp\backend\Models\Mood.cs | 10 | 0 | 1|
|smartapp\backend\Models\Picture.cs | 10 | 0 | 2|
|smartapp\backend\Models\Question.cs | 10 | 0 | 4|
|smartapp\frontend\src\assets\imgs\icons\like.svg | 10 | 0 | 0|
|smartapp\frontend\src\app\shared\interfaces\posts\report.ts | 10 | 0 | 7|
|smartapp\frontend\src\app\shared\interfaces\highlights\best-contributor.ts | 10 | 0 | 7|
|smartapp\frontend\src\app\shared\interfaces\posts\editable-post.ts | 10 | 0 | 1|
|smartapp\frontend\src\app\shared\interfaces\posts\edit-post.ts | 10 | 0 | 1|
|smartapp\frontend\src\app\shared\interfaces\posts\result.ts | 10 | 0 | 6|
|smartapp\frontend\src\app\modules\posts\modules\quote\create-settings\create-settings.component.html | 10 | 0 | 1|
|smartapp\frontend\src\app\modules\tabs\tabs.component.ts | 10 | 0 | 4|
|smartapp\frontend\src\app\modules\highlights\highlights.component.scss | 10 | 0 | 1|
|smartapp\frontend\src\main.ts | 9 | 0 | 3|
|smartapp\frontend\src\assets\sass\layout\main.scss | 9 | 0 | 0|
|smartapp\backend\ViewModels\ConfirmEmailVM.cs | 9 | 0 | 0|
|smartapp\backend\ViewModels\AnswerVM.cs | 9 | 0 | 2|
|smartapp\backend\Hive.csproj.user | 9 | 0 | 0|
|smartapp\backend\Models\AuthMessageSenderOptions.cs | 9 | 0 | 0|
|smartapp\backend\Models\Event.cs | 9 | 0 | 3|
|smartapp\backend\Models\Quote.cs | 9 | 0 | 3|
|smartapp\backend\.dockerignore | 9 | 0 | 0|
|smartapp\frontend\src\app\shared\interfaces\user\user-profile.ts | 9 | 0 | 6|
|smartapp\frontend\src\app\shared\interfaces\groups\group.ts | 9 | 0 | 6|
|smartapp\frontend\src\app\modules\highlights\general-mood\general-mood.component.html | 9 | 0 | 0|
|resources\files\help-line\Replay-help.md | 8 | 0 | 4|
|smartapp\frontend\src\app\shared\interfaces\user\user.ts | 8 | 0 | 5|
|smartapp\frontend\src\app\shared\interfaces\posts\post.ts | 8 | 0 | 5|
|smartapp\frontend\src\app\shared\interfaces\posts\reporting.ts | 8 | 0 | 4|
|smartapp\frontend\src\app\modules\account\modules\settings\languages\languages.component.html | 8 | 0 | 0|
|smartapp\frontend\ionic.config.json | 7 | 0 | 0|
|smartapp\backend\Models\ApplicationRole.cs | 7 | 0 | 1|
|smartapp\frontend\src\assets\imgs\icons\new-post.svg | 7 | 0 | 0|
|smartapp\frontend\src\assets\imgs\icons\dots-vertical-rounded.svg | 7 | 0 | 0|
|smartapp\frontend\src\app\shared\interfaces\posts\card-types.enum.ts | 7 | 0 | 3|
|smartapp\frontend\src\app\shared\interfaces\user\register.ts | 7 | 0 | 4|
|smartapp\frontend\src\app\shared\interfaces\groups\edit-group.ts | 7 | 0 | 4|
|smartapp\frontend\src\assets\imgs\icons\chevron-left-black.svg | 7 | 0 | 0|
|smartapp\frontend\test-config\mocks\statusBarMock.ts | 6 | 0 | 1|
|smartapp\frontend\test-config\mocks\splashScreenMock.ts | 6 | 0 | 1|
|smartapp\frontend\resources\README.md | 6 | 2 | 2|
|smartapp\frontend\src\app\shared\interfaces\tag-register.ts | 6 | 0 | 3|
|smartapp\frontend\src\app\shared\interfaces\user\update-password.ts | 6 | 0 | 3|
|smartapp\frontend\src\app\shared\interfaces\user\reset-password.ts | 6 | 0 | 3|
|smartapp\frontend\src\app\shared\interfaces\groups\create-group.ts | 6 | 0 | 3|
|resources\files\help-line\Question.md | 5 | 0 | 2|
|resources\files\lg-files\Flow_display_question.lg | 5 | 0 | 1|
|resources\files\help-line\Idea.md | 5 | 0 | 2|
|smartapp\frontend\test-config\mocks\titleMock.ts | 5 | 0 | 0|
|resources\files\help-line\Default_language.md | 5 | 0 | 4|
|smartapp\frontend\src\assets\imgs\icons\header\plus-white.svg | 5 | 0 | 0|
|smartapp\frontend\src\assets\imgs\icons\header\close-white.svg | 5 | 0 | 0|
|smartapp\frontend\src\assets\imgs\icons\close-white.svg | 5 | 0 | 0|
|smartapp\frontend\src\app\shared\interfaces\posts\choice.ts | 5 | 0 | 2|
|smartapp\frontend\src\app\shared\interfaces\posts\answer.ts | 5 | 0 | 2|
|smartapp\frontend\src\app\shared\interfaces\posts\creation-utils.ts | 5 | 0 | 1|
|smartapp\frontend\src\app\shared\interfaces\user\auth-data.ts | 5 | 0 | 0|
|smartapp\frontend\src\assets\imgs\icons\close-blue.svg | 5 | 0 | 0|
|smartapp\frontend\src\assets\imgs\icons\check-white.svg | 5 | 0 | 0|
|resources\files\lg-files\EventImage_question.lg | 4 | 0 | 1|
|resources\files\lg-files\Default_language.lg | 4 | 0 | 1|
|resources\files\lg-files\IdeaImage_question.lg | 4 | 0 | 1|
|resources\files\lg-files\Icon_question.lg | 4 | 0 | 1|
|resources\files\lg-files\SuggestionImage_question.lg | 4 | 0 | 1|
|smartapp\backend\Views\_ViewImports.cshtml | 4 | 0 | 1|
|resources\files\lg-files\Title_question.lg | 4 | 0 | 2|
|resources\files\lg-files\Splash_question.lg | 4 | 0 | 1|
|resources\files\lg-files\Server_url_question.lg | 4 | 0 | 1|
|resources\files\lg-files\Secondary_color_question.lg | 4 | 0 | 1|
|resources\files\lg-files\QuoteImage_question.lg | 4 | 0 | 1|
|resources\files\lg-files\QuestionImage_question.lg | 4 | 0 | 2|
|resources\files\lg-files\Primary_color_question.lg | 4 | 0 | 1|
|resources\files\help-line\Flow_display.md | 4 | 0 | 3|
|smartapp\frontend\src\app\shared\interfaces\user\user-view-card.ts | 4 | 0 | 1|
|smartapp\frontend\src\app\shared\interfaces\user\update-profile-picture.ts | 4 | 0 | 1|
|smartapp\frontend\src\app\shared\interfaces\user\sign-in.ts | 4 | 0 | 1|
|smartapp\frontend\src\app\shared\interfaces\highlights\general-mood.ts | 4 | 0 | 1|
|smartapp\frontend\src\app\shared\interfaces\posts\pictureModel.ts | 4 | 0 | 1|
|smartapp\frontend\src\app\shared\interfaces\groups\update-members.ts | 4 | 0 | 1|
|smartapp\frontend\src\app\shared\interfaces\groups\target-group.ts | 4 | 0 | 1|
|smartapp\frontend\src\polyfills.ts | 3 | 57 | 9|
|resources\files\lg-files\Like_question.lg | 3 | 0 | 0|
|resources\files\help-line\Server_url.md | 3 | 0 | 2|
|smartapp\frontend\src\assets\sass\layout\_all.scss | 3 | 0 | 0|
|resources\files\lg-files\Suggestion_question.lg | 3 | 0 | 0|
|resources\files\lg-files\Replay_question.lg | 3 | 0 | 1|
|resources\files\lg-files\Quote_question.lg | 3 | 0 | 0|
|smartapp\frontend\src\environments\environment.prod.ts | 3 | 0 | 0|
|smartapp\frontend\src\environments\environment.ts | 3 | 11 | 2|
|smartapp\backend\.bowerrc | 3 | 0 | 0|
|smartapp\frontend\src\app\shared\interfaces\posts\pictureVM.ts | 3 | 0 | 0|
|smartapp\frontend\src\app\modules\posts\posts.component.html | 3 | 0 | 4|
|smartapp\frontend\src\app\modules\posts\modules\quote\quote.component.scss | 3 | 0 | 0|
|smartapp\frontend\src\app\modules\posts\modules\question\question.component.scss | 3 | 0 | 0|
|smartapp\frontend\src\app\modules\posts\modules\quote\create-question\create-question.component.html | 3 | 0 | 1|
|smartapp\frontend\src\app\modules\posts\modules\event\event.component.scss | 3 | 0 | 0|
|smartapp\frontend\src\app\modules\account\components\change-password\change-password.component.scss | 3 | 0 | 0|
|smartapp\frontend\src\app\app.component.html | 3 | 0 | 0|
|resources\files\lg-files\Post_creation.lg | 2 | 0 | 0|
|smartapp\frontend\src\assets\sass\components\posts\_all.scss | 2 | 0 | 0|
|smartapp\frontend\src\zone-flags.ts | 1 | 4 | 0|
|smartapp\frontend\src\assets\shapes.svg | 1 | 0 | 0|
|smartapp\frontend\src\assets\sass\base\_all.scss | 1 | 0 | 0|
|smartapp\frontend\src\assets\sass\views\_all.scss | 1 | 0 | 0|
|smartapp\frontend\resources\icon.png.md5 | 1 | 0 | 0|
|smartapp\frontend\src\assets\imgs\icons\email.svg | 1 | 0 | 0|
|smartapp\frontend\src\assets\imgs\icons\plus.svg | 1 | 0 | 0|
|smartapp\frontend\src\assets\imgs\icons\password.svg | 1 | 0 | 0|
|smartapp\frontend\src\assets\imgs\icons\minus.svg | 1 | 0 | 0|
|smartapp\frontend\src\assets\imgs\icons\dots-horizontal-rounded.svg | 1 | 0 | 0|
|smartapp\frontend\src\assets\imgs\icons\chevron-right.svg | 1 | 0 | 0|
|smartapp\frontend\src\assets\imgs\icons\check.svg | 1 | 0 | 0|
|smartapp\frontend\src\assets\imgs\icons\camera.svg | 1 | 0 | 0|
|resources\files\create_question.jpg | binary file|
|resources\files\create_mood.jpg | binary file|
|resources\files\6.png | binary file|
|resources\files\create_idea.jpg | binary file|
|resources\files\create_event.jpg | binary file|
|resources\files\icon.png | binary file|
|smartapp\frontend\src\assets\icon\favicon.png | binary file|
|smartapp\frontend\src\assets\imgs\create_idea.jpg | binary file|
|smartapp\frontend\src\assets\imgs\Happy.png | binary file|
|smartapp\frontend\resources\icon.png | binary file|
|smartapp\frontend\src\assets\imgs\Indifferent.png | binary file|
|smartapp\backend\Models\Idea.cs | 0 | 0 | 1|
|smartapp\frontend\src\assets\imgs\images.jpg | binary file|
|smartapp\frontend\src\assets\imgs\logo.png | binary file|
|smartapp\frontend\src\assets\imgs\Sunglasses.png | binary file|
|smartapp\frontend\src\assets\imgs\photo.jpg | binary file|
|smartapp\frontend\src\assets\imgs\Sad.png | binary file|
|smartapp\frontend\src\assets\imgs\Muted.png | binary file|
|smartapp\frontend\src\assets\imgs\icons\posts\more-vertical@2x.png | binary file|
|smartapp\frontend\src\assets\imgs\icons\posts\more-vertical.png | binary file|
|smartapp\frontend\src\assets\imgs\icons\groups\more.PNG | binary file|
|smartapp\frontend\src\app\shared\components\event-card\event-card.component.scss | 0 | 0 | 1|
|smartapp\frontend\src\app\shared\components\quote-card\quote-card.component.scss | 0 | 0 | 1|
|smartapp\frontend\resources\hive-earth.png | binary file|
|smartapp\frontend\src\app\shared\components\question-card\question-card.component.scss | 0 | 0 | 1|
|smartapp\frontend\src\app\shared\components\mood-card\mood-card.component.scss | 0 | 0 | 0|
|smartapp\frontend\src\app\shared\components\reporting-card\reporting-card.component.scss | 0 | 0 | 0|
|smartapp\frontend\src\app\modules\posts\posts.component.scss | 0 | 0 | 0|
|smartapp\frontend\src\app\modules\posts\modules\quote\preview\preview.component.scss | 0 | 0 | 1|
|smartapp\frontend\src\app\modules\posts\modules\quote\create-settings\create-settings.component.scss | 0 | 0 | 1|
|smartapp\frontend\src\app\modules\posts\modules\quote\edit-quote-modal\edit-quote-modal.component.scss | 0 | 0 | 1|
|smartapp\frontend\src\app\modules\posts\components\top-posts\top-posts.component.scss | 0 | 0 | 0|
|smartapp\frontend\src\app\modules\posts\modules\question\preview\preview.component.scss | 0 | 0 | 1|
|smartapp\frontend\src\app\modules\posts\modules\question\create-settings\create-settings.component.scss | 0 | 0 | 1|
|smartapp\frontend\src\app\modules\posts\modules\question\create-question\create-question.component.scss | 0 | 0 | 1|
|smartapp\frontend\src\app\modules\posts\modules\quote\create-question\create-question.component.scss | 0 | 0 | 1|
|smartapp\frontend\src\app\modules\posts\modules\question\create-answers\create-answers.component.scss | 0 | 0 | 1|
|smartapp\frontend\src\app\modules\posts\modules\event\preview\preview.component.scss | 0 | 0 | 1|
|smartapp\frontend\src\app\modules\posts\modules\event\create-settings\create-settings.component.scss | 0 | 0 | 1|
|smartapp\frontend\src\app\modules\posts\components\post-details-modal\post-details-modal.component.scss | 0 | 0 | 0|
|smartapp\frontend\src\app\modules\highlights\best-post\best-post.component.scss | 0 | 0 | 0|
|smartapp\frontend\src\app\modules\highlights\top-posts\top-posts.component.scss | 0 | 0 | 0|
|smartapp\frontend\src\app\modules\authentication\login\login.component.scss | 0 | 0 | 0|
|smartapp\frontend\src\app\modules\authentication\register\register.component.scss | 0 | 0 | 0|
|smartapp\frontend\src\app\modules\account\modules\settings\languages\languages.component.scss | 0 | 0 | 0|
|smartapp\frontend\src\app\modules\account\modules\settings\settings.component.scss | 0 | 0 | 0|
|smartapp\frontend\src\app\modules\account\modules\manage-groups\manage-groups.component.scss | 0 | 0 | 0|
|smartapp\frontend\src\app\modules\account\modules\manage-groups\edit-members-modal\edit-members-modal.component.scss | 0 | 0 | 0|
|smartapp\frontend\src\app\modules\account\modules\manage-groups\group-details\group-details.component.scss | 0 | 0 | 0|
|smartapp\frontend\src\app\modules\account\modules\manage-groups\edit-group-modal\edit-group-modal.component.scss | 0 | 0 | 0|
|smartapp\frontend\src\app\modules\account\modules\manage-groups\create-group-modal\create-group-modal.component.scss | 0 | 0 | 0|
|smartapp\frontend\src\app\modules\account\account.component.scss | 0 | 0 | 0|
|smartapp\frontend\src\app\app.component.scss | 0 | 0 | 0|
|resources\files\splash.png | binary file|
|smartapp\frontend\resources\splash.png | binary file|
|||||

***


