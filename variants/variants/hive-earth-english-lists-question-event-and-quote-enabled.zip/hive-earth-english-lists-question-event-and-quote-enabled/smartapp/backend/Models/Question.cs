
using System;

namespace Hive.Backend.DataModels
{
    public class Question : Card
    {
        public Question() : base()
        {

        }
    }
}

