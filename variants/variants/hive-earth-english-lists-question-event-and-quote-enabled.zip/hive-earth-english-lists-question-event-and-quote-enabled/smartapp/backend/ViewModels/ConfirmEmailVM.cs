﻿
namespace Hive.Backend.ViewModels
{
    public class ConfirmEmailVM
    {
        public string UserId { get; set; }
        public string Code { get; set; }
    }
}
