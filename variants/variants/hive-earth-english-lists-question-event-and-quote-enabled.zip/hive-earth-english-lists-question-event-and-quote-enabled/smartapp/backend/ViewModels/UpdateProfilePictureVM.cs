﻿
namespace Hive.Backend.ViewModels
{
    public class UpdateProfilePictureVM
    {
        public UpdateProfilePictureVM()
        {
        }

        public string UserProfileId { get; set; }
        public string Picture { get; set; }
    }
}
