export interface UpdatePassword {
  email: string;

  currentPassword: string;

  password: string;

  confirmPassword: string;
}
