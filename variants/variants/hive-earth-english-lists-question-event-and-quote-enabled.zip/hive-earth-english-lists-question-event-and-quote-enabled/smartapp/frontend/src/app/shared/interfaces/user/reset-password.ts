export interface ResetPassword {
  email: string;

  password: string;

  confirmPassword: string;
  
  code: string;
}
