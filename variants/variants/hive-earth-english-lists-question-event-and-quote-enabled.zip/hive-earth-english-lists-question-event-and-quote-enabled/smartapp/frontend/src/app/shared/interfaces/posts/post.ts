export interface Post {
  id: string;

  content: string;

  publicationDate: Date;

  endDate: Date;

  status: string;

  type: string;
}
