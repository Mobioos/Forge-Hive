export interface BestContributor {
  posts: number;

  answers: number;

  pictureUrl: string;

  firstname: string;

  lastname: string;

  department: string;

  city: string;

  country: string;
}
