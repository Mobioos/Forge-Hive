export interface EditGroup {
  name: string;

  city: string;

  country: string;

  createdbyId: number;

  id: number;
}
