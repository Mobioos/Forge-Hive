import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MoodCardComponent } from './components/mood-card/mood-card.component';
import { QuoteCardComponent } from './components/quote-card/quote-card.component';
import { TranslateModule } from '@ngx-translate/core';

import { QuestionCardComponent } from './components/question-card/question-card.component';
import { ReportingCardComponent } from './components/reporting-card/reporting-card.component';

import { EventCardComponent } from './components/event-card/event-card.component';



@NgModule({
  declarations: [
    
    QuestionCardComponent,
    ReportingCardComponent,
    
    EventCardComponent,
    MoodCardComponent,
    QuoteCardComponent
  ],
  imports: [
    CommonModule,
    TranslateModule.forChild()
  ],
  exports: [
    
    QuestionCardComponent,
    ReportingCardComponent,
    
    EventCardComponent,
    MoodCardComponent,
    QuoteCardComponent
  ]
})
export class SharedModule { }

