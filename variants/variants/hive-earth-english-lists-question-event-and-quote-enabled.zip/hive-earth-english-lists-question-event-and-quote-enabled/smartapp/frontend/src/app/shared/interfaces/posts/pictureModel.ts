export interface PictureModel {
  id: number;

  PicBase64: string;
}
