export interface Answer {
  idUser: string;

  idCard: string;

  idChoice: string;
}
