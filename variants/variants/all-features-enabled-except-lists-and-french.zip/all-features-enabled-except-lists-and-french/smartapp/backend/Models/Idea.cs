
namespace Hive.Backend.DataModels
{
	public class Idea : Card
	{
		public Idea() : base()
		{
		}

	}
}
