
namespace Hive.Backend.DataModels
{
	public class Choice : Identifier
	{
		public Choice() : base()
		{
		}

		public string Name { get; set; }
	}
}