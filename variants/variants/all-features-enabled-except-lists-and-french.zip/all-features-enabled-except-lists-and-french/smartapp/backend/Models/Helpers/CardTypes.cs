
namespace Hive.Backend.Models
{
    public enum CardTypes
    {
        Reporting,
        Idea,
        Question,
        Event,
        Mood,
        Quote,
        Suggestion
    }
}

