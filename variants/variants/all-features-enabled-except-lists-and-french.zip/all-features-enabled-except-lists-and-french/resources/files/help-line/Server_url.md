# What should the application's backend sub domain be?

That's a question  should be asked to an IT type of Fusion user, as of now this application will be deployed to our own Azure cloud and you can here choose how the asset in Azure should be named.

That feature will help technicians manage deployed FocusApp efficiently when the deployment servers will also be managed by said technicians.

For this demo, feel free to choose any name (the same as the application name seem to be the most straight forward option here).