﻿
namespace Hive.Backend.DataModels
{
    public class Mood : Card
    {
        public Mood() : base()
        {

        }
    }
}
