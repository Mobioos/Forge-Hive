
namespace Hive.Backend.Models
{
    public enum CardTypes
    {
        Reporting,

        Question,
        Event,
        Mood

    }
}

