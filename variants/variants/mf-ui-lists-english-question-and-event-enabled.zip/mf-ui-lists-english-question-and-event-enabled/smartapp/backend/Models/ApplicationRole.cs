﻿using Microsoft.AspNetCore.Identity;

namespace Hive.Backend.Models
{
    public class ApplicationRole<T> : IdentityRole<string>
    {
    }
}
