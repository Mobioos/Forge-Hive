
namespace Hive.Backend.DataModels
{
    public class Event : Card
    {
        public Event() : base()
        {

        }
    }
}

