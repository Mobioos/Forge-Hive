export interface TargetGroup {
  id: string;

  name: string;
}
