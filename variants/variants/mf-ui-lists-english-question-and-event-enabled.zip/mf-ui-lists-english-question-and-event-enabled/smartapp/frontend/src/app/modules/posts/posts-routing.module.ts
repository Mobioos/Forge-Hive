import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { ChooseNewPostCategoryComponent } from "./components/choose-new-post-category/choose-new-post-category.component";
import { PostsMainComponent } from "./components/posts-main/posts-main.component";
import { PostsComponent } from "./posts.component";

const routes: Routes = [
  {
    path: '',
    component: PostsComponent,
    children: [
      {
        path: '',
        redirectTo: 'main'
      },
      {
        path: 'main',
        component: PostsMainComponent
      },
      {
        path: 'newPost',
        component: ChooseNewPostCategoryComponent,
      },
      {
        path: 'event',
        loadChildren: () => import('./modules/event/event.module').then(m => m.EventModule)
      },

      {
        path: 'question',
        loadChildren: () => import('./modules/question/question.module').then(m => m.QuestionModule)
      },

    ]
  },
  {
    path: '',
    redirectTo: 'main'
  }
]

@NgModule({
  imports: [
    RouterModule.forChild(routes)
  ],
  exports: [RouterModule]
})
export class PostsRoutingModule { }

