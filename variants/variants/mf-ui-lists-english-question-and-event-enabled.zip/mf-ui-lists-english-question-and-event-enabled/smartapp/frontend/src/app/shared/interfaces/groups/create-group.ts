export interface CreateGroup {
  name: string;

  city: string;

  country: string;

  createdbyId: number;
}
