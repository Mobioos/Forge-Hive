export interface AuthData {
    id: string;
    auth_token : string;
    expires_in: string;
}