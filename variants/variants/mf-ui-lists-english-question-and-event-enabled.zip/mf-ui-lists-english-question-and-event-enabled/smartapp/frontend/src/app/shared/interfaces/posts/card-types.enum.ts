export enum CardTypes {
  Reporting,
  
  Question,
  Event,
  Mood

};

